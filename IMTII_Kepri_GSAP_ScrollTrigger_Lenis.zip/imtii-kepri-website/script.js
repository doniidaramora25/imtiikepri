// IMTII Kepri — navigation, Lenis smooth scroll, GSAP ScrollTrigger & interactions
(() => {
  const menuButton = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".nav-links");
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Mobile navigation
  menuButton?.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuButton.setAttribute("aria-expanded", String(open));
    menuButton.textContent = open ? "×" : "☰";
  });
  document.querySelectorAll(".nav-links a").forEach(link => link.addEventListener("click", () => {
    nav?.classList.remove("open");
    menuButton?.setAttribute("aria-expanded", "false");
    if (menuButton) menuButton.textContent = "☰";
  }));

  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  // GSAP + ScrollTrigger + Lenis. Native scrolling remains the fallback.
  const hasMotionLibraries = Boolean(window.gsap && window.ScrollTrigger && window.Lenis);
  let lenis = null;
  if (!reduceMotion && hasMotionLibraries) {
    gsap.registerPlugin(ScrollTrigger);
    lenis = new Lenis({
      duration: 1.05,
      smoothWheel: true,
      wheelMultiplier: 0.9,
      touchMultiplier: 1.15,
      anchors: { offset: -88 }
    });
    lenis.on("scroll", ScrollTrigger.update);
    gsap.ticker.add(time => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);

    // Anchor navigation is routed through Lenis to avoid competing scroll engines.
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener("click", event => {
        const href = anchor.getAttribute("href");
        if (!href || href === "#") return;
        const target = document.querySelector(href);
        if (!target) return;
        event.preventDefault();
        lenis.scrollTo(target, { offset: -88, duration: 1.15 });
        if (history.replaceState) history.replaceState(null, "", href);
      });
    });

    // Entrance animation for the hero.
    gsap.fromTo(".hero-copy > *",
      { autoAlpha: 0, y: 28 },
      { autoAlpha: 1, y: 0, duration: 0.85, stagger: 0.12, ease: "power3.out", delay: 0.12 }
    );
    gsap.fromTo(".hero-visual",
      { autoAlpha: 0, y: 35, rotate: -2 },
      { autoAlpha: 1, y: 0, rotate: 0, duration: 1.1, ease: "power3.out", delay: 0.28 }
    );

    // Reusable reveal animation for every content section.
    const reveal = (elements, options = {}) => {
      gsap.fromTo(elements,
        { autoAlpha: 0, y: options.y ?? 38 },
        {
          autoAlpha: 1, y: 0,
          duration: options.duration ?? 0.85,
          stagger: options.stagger ?? 0,
          ease: options.ease ?? "power3.out",
          scrollTrigger: {
            trigger: options.trigger || elements,
            start: options.start || "top 86%",
            once: true
          }
        }
      );
    };

    document.querySelectorAll(".intro .two-col > *, .section-heading").forEach(el => reveal(el, { y: 30 }));
    reveal(".value-card", { trigger: ".value-grid", stagger: 0.13, y: 46 });
    reveal(".program-list article", { trigger: ".program-list", stagger: 0.12, y: 32 });
    reveal(".news-card", { trigger: ".news-grid", stagger: 0.15, y: 48 });
    reveal(".gallery-tile", { trigger: ".gallery-grid", stagger: 0.14, y: 45 });
    reveal(".agenda-wrap > div", { trigger: ".agenda-wrap", stagger: 0.16, y: 38 });
    reveal(".join-wrap > div", { trigger: ".join-wrap", stagger: 0.16, y: 38 });
    reveal(".footer-top > *, .footer-bottom > *", { trigger: ".footer", stagger: 0.08, y: 18, duration: 0.65 });

    // Subtle parallax depth on decorative hero elements.
    gsap.to(".visual-orbit.orbit-one", {
      rotate: 18, y: -22, ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: 1 }
    });
    gsap.to(".visual-orbit.orbit-two", {
      rotate: -14, y: 18, ease: "none",
      scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: 1 }
    });
  } else {
    // Accessible native smooth-scroll fallback (also used when a CDN is unavailable).
    if (!reduceMotion) {
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener("click", event => {
          const href = anchor.getAttribute("href");
          if (!href || href === "#") return;
          const target = document.querySelector(href);
          if (!target) return;
          event.preventDefault();
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          if (history.replaceState) history.replaceState(null, "", href);
        });
      });
    }
  }

  // Scroll progress and compact header state.
  const progressBar = document.getElementById("scroll-progress-bar");
  const header = document.querySelector(".site-header");
  let scrollTicking = false;
  function updateScrollUI() {
    const scrollable = document.documentElement.scrollHeight - window.innerHeight;
    const progress = scrollable > 0 ? window.scrollY / scrollable : 0;
    if (progressBar) progressBar.style.transform = `scaleX(${Math.min(1, Math.max(0, progress))})`;
    header?.classList.toggle("is-scrolled", window.scrollY > 12);
    scrollTicking = false;
  }
  window.addEventListener("scroll", () => {
    if (!scrollTicking) {
      window.requestAnimationFrame(updateScrollUI);
      scrollTicking = true;
    }
  }, { passive: true });
  lenis?.on("scroll", updateScrollUI);
  updateScrollUI();

  // Custom cursor: desktop precise pointers only.
  const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  if (finePointer && !reduceMotion) {
    const dot = document.querySelector(".cursor-dot");
    const outline = document.querySelector(".cursor-outline");
    if (dot && outline) {
      document.body.classList.add("has-custom-cursor");
      let mouseX = window.innerWidth / 2, mouseY = window.innerHeight / 2;
      let outlineX = mouseX, outlineY = mouseY;
      window.addEventListener("mousemove", event => {
        mouseX = event.clientX; mouseY = event.clientY;
        dot.style.left = `${mouseX}px`; dot.style.top = `${mouseY}px`;
      }, { passive: true });
      const followCursor = () => {
        outlineX += (mouseX - outlineX) * 0.18;
        outlineY += (mouseY - outlineY) * 0.18;
        outline.style.left = `${outlineX}px`; outline.style.top = `${outlineY}px`;
        window.requestAnimationFrame(followCursor);
      };
      followCursor();
      document.querySelectorAll("a, button, .value-card, .news-card, .gallery-tile").forEach(element => {
        element.addEventListener("mouseenter", () => document.body.classList.add("cursor-hover"));
        element.addEventListener("mouseleave", () => document.body.classList.remove("cursor-hover"));
      });
      document.addEventListener("mouseleave", () => document.body.classList.remove("cursor-hover"));
    }
  }

  // Ganti URL Google Form di index.html pada elemen dengan id="join-link".
  // Konten contoh perlu diganti dengan data resmi organisasi sebelum publikasi.
})();
